    {{-- <footer class="p-2 text-white" style="background-color:rgba(0, 0, 0, 0.772)">

            <div class="container" style="text-align:center">
                <p>Design and Developed by https://chiralbd.org</p>
             </div>
        


    </footer>
 --}}
